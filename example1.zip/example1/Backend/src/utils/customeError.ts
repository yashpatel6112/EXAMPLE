export class CustomError extends Error {
    STATUSCODE: number;
    data: any;
    success: boolean;
    errors: any[];
    constructor(
        STATUSCODE: number,
        message: string = "Something went wrong",
        errors: any = []
    ) {
        super(message);
        this.STATUSCODE = STATUSCODE;
        this.data = null;
        this.success = false;
        this.errors = errors;
    }
    getErrorResponse() {
        return {
            success: this.success,
            statusCode: this.STATUSCODE,
            message: this.message,
            data: this.data,
            errors: this.errors,
        };
    }
}
