class customResponse {
    STATUSCODE: number;
    data: any;
    message: string;
    success: boolean;

    constructor(STATUSCODE: number, data: any, message: string = "Success") {
        this.STATUSCODE = STATUSCODE;
        this.data = data;
        this.message = message;
        this.success = STATUSCODE < 400;
    }
}

export { customResponse };
