import { TYPES } from "@constants";
import { AuthService } from "@services";
import { CustomError } from "@utils";
import { inject } from "inversify";
import { Request, Response } from "express";
import { controller, httpPost } from "inversify-express-utils";

@controller("/auth")
export class AuthController {
    constructor(
        @inject<AuthService>(TYPES.AuthService)
        private authService: AuthService
    ) {}

    @httpPost("/register")
    async register(req: Request, res: Response): Promise<void> {
        try {
            const { name, email, password } = req.body;
            const existedUser = await this.authService.getUserByEmail(email);
            if (existedUser) {
                throw new CustomError(400, "User already exists");
            }
            const user = await this.authService.registerService({
                name,
                email,
                password,
            });
            res.status(201).json({
                data: user,
                message: "User registered successfully",
            });
        } catch (error: any) {
            throw new CustomError(500, error.message);
        }
    }
}
