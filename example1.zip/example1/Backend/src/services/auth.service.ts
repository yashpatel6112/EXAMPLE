import { injectable } from "inversify";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import config from "config";
import { User } from "@models";
import { CustomError } from "@utils";

@injectable()
export class AuthService {
    async getUserByEmail(email: string) {
        try {
            const user = await User.findOne({ email });
            return user;
        } catch (error: any) {
            throw new CustomError(500, error.message);
        }
    }
    async registerService(data: object) {
        try {
            const user = await User.create(data);
            const createdUser = await User.findById(user._id).select(
                "-password -__v"
            );
            return createdUser.toObject();
        } catch (error: any) {
            throw new CustomError(500, error.message);
        }
    }
    async loginService(data: object) {}
}
