import express from "express";
import cors from "cors";
import config from "config";
import { InversifyExpressServer } from "inversify-express-utils";
import { container } from "./inversify.config";
import { connectDatabase } from "./database/database";
import cookieParser from "cookie-parser";

const app = express();
app.use(
    cors({
        origin: config.get("CORS_ORIGIN"),
        credentials: true,
    })
);
app.options("*", cors({ origin: "*", credentials: true }));
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

const server = new InversifyExpressServer(container, app, {
    rootPath: "/api/v1",
});

server.setConfig(async (app) => {
    app.get("/", (_, res) => {
        res.send("Hello World");
    });
});

server.build().listen(config.get("PORT"), () => {
    console.log(`Server is running on http://localhost:${config.get("PORT")}`);
    connectDatabase();
});
