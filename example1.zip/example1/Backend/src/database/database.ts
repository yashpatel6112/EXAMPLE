import config from "config";
import mongoose from "mongoose";

const connectDatabase = async () => {
  try {
    await mongoose.connect(config.get("MONGODB_URL"));
    console.log("Connected to MongoDB successfully.");
  } catch (error: unknown) {
    console.log("MONGODB connection error: ", error);
    process.exit(1);
  }
};

export { connectDatabase };
