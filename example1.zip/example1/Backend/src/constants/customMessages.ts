const ERROR_MESSAGE = {
    UNAUTHORIZED_REQUEST: "Unauthorized request",
};

const SUCCESS_MESSAGE = {
    SUCCESS: "Success",
};

export { ERROR_MESSAGE, SUCCESS_MESSAGE };