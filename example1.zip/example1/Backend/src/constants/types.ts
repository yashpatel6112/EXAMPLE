export const TYPES = {
    AuthService: Symbol.for("AuthService"),
};
