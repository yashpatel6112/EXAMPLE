export const STATUSCODE = {
    UNAUTHORIZED_STATUS: 401,
};
