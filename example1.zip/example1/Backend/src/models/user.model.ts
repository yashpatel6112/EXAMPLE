import bcrypt from "bcrypt";
import mongoose, { Schema } from "mongoose";

const userSchema = new Schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
    },
    password: {
        type: String,
        required: true,
    },
});

userSchema.pre("save", function (next) {
    if (this.isModified("password")) {
        const hashPassword = bcrypt.hashSync(this.password, 10);
        this.password = hashPassword;
        next();
    }
    next();
});

export const User = mongoose.model("User", userSchema);
