import jwt from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";
import { CustomError } from "@utils";
import config from "config";
import { BaseMiddleware } from "inversify-express-utils";
import { ERROR_MESSAGE, STATUSCODE } from "@constants";

export class AuthMiddleware extends BaseMiddleware {
    public async handler(req: Request, res: Response, next: NextFunction) {
        try {
            const token =
                req.headers.authorization?.split("Bearer ")[1] ||
                (req.cookies?.otpToken as string);
            if (!token || typeof token !== "string") {
                throw new CustomError(
                    STATUSCODE.UNAUTHORIZED_STATUS,
                    ERROR_MESSAGE.UNAUTHORIZED_REQUEST
                );
            }
            let decodeToken;
            if (req.cookies?.otpToken) {
                decodeToken = jwt.verify(
                    token,
                    config.get("OTP_SECRET_KEY") as string
                ) as { _id: string };
            } else {
                decodeToken = jwt.verify(
                    token,
                    config.get("SECRET_KEY") as string
                ) as {
                    _id: string;
                };
            }
            if (!decodeToken) {
                throw new CustomError(
                    STATUSCODE.UNAUTHORIZED_STATUS,
                    ERROR_MESSAGE.UNAUTHORIZED_REQUEST
                );
            }
            req.headers.user = decodeToken._id;
            next();
        } catch (error: any) {
            next(
                new CustomError(STATUSCODE.UNAUTHORIZED_STATUS, error.message)
            );
        }
    }
}
