import { TYPES } from "@constants";
import "@controllers";
import { AuthService } from "@services";
import { Container } from "inversify";

const container = new Container();
container.bind<AuthService>(TYPES.AuthService).to(AuthService);

export { container };
